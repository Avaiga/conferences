# Milestone 12

This milestone shows a small real-life example of an application built with Taipy.

The scenario is similar to the one we used in previous milestones, except that we
start the process from an existing pickle model.<br/>

## Files
   * `shared`: a directory where the source files used for the configuration of the applications are stored.<br/>
      The demonstration source files explicitly import that directory.
   * `demo_cli.py`: .
   * `demo.py`: 
